ALTER TABLE `colleges` ADD `students_count` int;--> statement-breakpoint
ALTER TABLE `colleges` ADD `youtube_video` text;