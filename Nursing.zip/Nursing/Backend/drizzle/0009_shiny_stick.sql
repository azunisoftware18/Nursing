ALTER TABLE `leads` MODIFY COLUMN `name` varchar(150);--> statement-breakpoint
ALTER TABLE `leads` MODIFY COLUMN `state` varchar(100);--> statement-breakpoint
ALTER TABLE `leads` MODIFY COLUMN `city` varchar(100);