export * from './user.schema.js';
export * from "./college.schema.js";
export * from "./course.schema.js";
export * from "./blog.schema.js";
export * from "./lead.schema.js";
export * from "./auditLog.schema.js";